#!/bin/bash
z="
";Tz='eK1n';Vz='6YX'\''';dz='PORT';Pz='ion'\''';Fz='spee';Bz='='\''db';Rz='='\''LI';az='Ndba';Wz='DB='\''';bz='seRO';Lz='='\''pr';Kz='USER';Mz='ojec';Oz='1n6L';Ez='.top';Iz='er.x';Jz='yz'\''';Cz='lion';Yz='ectv';fz='06'\''';Xz='proj';Az='HOST';cz='ARR'\''';Hz='serv';Nz='tv_K';ez='='\''33';Dz='roar';Gz='dvpn';Uz='6K0n';Zz='_LIO';Sz='ON.s';Qz='PASS';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$z$Kz$Lz$Mz$Nz$Oz$Pz$z$Qz$Rz$Sz$Tz$Uz$Vz$z$Wz$Xz$Yz$Zz$az$bz$cz$z$dz$ez$fz"